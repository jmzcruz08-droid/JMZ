# 101 Safe Dashboard

A clean Android replacement project for Globe The 101 (hardware V1.0, firmware RA_M1_v5.2.00g).

## Safety scope
- No firmware image or firmware updater is included.
- No router login, password collection, shell execution, command injection, upload, or modem write operation.
- Displays the user-provided modem profile.
- Shows the phone's current network transport (Wi-Fi/mobile data).
- Includes an optional HTTPS download speed test (5 MB; uses internet data).
- Shows cooling guidance. Modem temperature and modem-side 4G/5G/signal are unavailable until a documented read-only API is verified.

## Build from an Android phone using GitHub Actions
1. Extract this ZIP on your phone.
2. Create a new GitHub repository named `101-safe-dashboard`.
3. Upload the **contents** of this folder to the repository's `main` branch (not the ZIP itself). Include the hidden `.github/workflows/build-apk.yml` file.
4. Open the repository's **Actions** tab. Select **Build safe dashboard APK** and tap **Run workflow** (or wait for the first push build).
5. When the run finishes successfully, open it and download the artifact named `101-safe-dashboard-debug-apk`.
6. Extract the artifact ZIP. Install `app-debug.apk` on your Android phone. If Android asks, allow installs from the browser/file manager you used.

## Build locally
Open this folder in Android Studio, allow Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
Requirements: JDK 17 and Android SDK Platform 35. The GitHub Actions workflow uses Java 17 and Gradle 8.7.

## Important
This is a new safe app, not a patched copy of `BUGOK101_2.9.15_sign.apk`. Do not install or run the original updater APK against the modem. The new app has a different application ID: `com.globe101.safedashboard`.
